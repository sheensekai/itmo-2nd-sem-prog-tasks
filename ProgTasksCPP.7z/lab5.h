#ifndef PROGTASKSCPP_LAB5_H
#define PROGTASKSCPP_LAB5_H


class ICircle {
public:
    virtual double square() = 0;
    virtual double len() = 0;
};


#endif //PROGTASKSCPP_LAB5_H
