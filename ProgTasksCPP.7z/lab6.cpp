#include <iostream>
template <typename Type>
void func(Type var) {
    std::cout << var;
}